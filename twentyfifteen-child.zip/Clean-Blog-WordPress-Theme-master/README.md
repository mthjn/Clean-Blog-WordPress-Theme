# Clean-Blog-WordPress-Theme
simple wordpress theme quickly put together as twentyfifteen child  
based on [startbootstrap's clean blog](http://ironsummitmedia.github.io/startbootstrap-clean-blog/) and wp defaut 2015 theme.  
  
note. I probably screwed up chown somewhere along the way so if you want to install this maybe you want to wait until I fix it.  
  
front 
![front](http://ibin.co/28ltTNaJIKtD)
page  
![page](http://ibin.co/28lu4X85G9mx)
blog w thumbnail  
![blog w thumbnail](http://ibin.co/28luKliiyfLr)
blog w no thumbnail  
![blog w no thumbnail](http://ibin.co/28luQhVsihpf)
  
### notes
[deploy on heroku](https://ksylvest.com/posts/2014-05-02/deploying-wordpress-to-heroku)
